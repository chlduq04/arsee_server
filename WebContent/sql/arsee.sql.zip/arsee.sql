-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- 호스트: localhost
-- 처리한 시간: 14-09-14 13:33 
-- 서버 버전: 5.1.41
-- PHP 버전: 5.2.12

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 데이터베이스: `arsee`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `arsee_ars_infos`
--

CREATE TABLE IF NOT EXISTS `arsee_ars_infos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text COLLATE utf8_unicode_ci,
  `number` text COLLATE utf8_unicode_ci,
  `depth` text COLLATE utf8_unicode_ci,
  `indexs` text COLLATE utf8_unicode_ci,
  `parent` text COLLATE utf8_unicode_ci,
  `company` text COLLATE utf8_unicode_ci,
  `starttime` time DEFAULT NULL,
  `endtime` time DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  `info` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `normal` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `error` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `star` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sharp` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=22 ;

--
-- 테이블의 덤프 데이터 `arsee_ars_infos`
--

INSERT INTO `arsee_ars_infos` (`id`, `text`, `number`, `depth`, `indexs`, `parent`, `company`, `starttime`, `endtime`, `count`, `info`, `normal`, `error`, `star`, `sharp`) VALUES
(8, '청구요금 확인', '114', '0', '1', '0', 'skt', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(6, 'start', '114', '0', '#', '0', 'skt', '00:00:00', '24:00:00', 1, NULL, NULL, NULL, NULL, '1'),
(7, '상담 사 연결', '114', '0', '0', '0', 'skt', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(9, '당월 실시간 요금', '114', '0', '2', '0', 'skt', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(10, '잔여 무료 통화, 무료 문자', '114', '0', '3', '0', 'skt', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(11, '납부 전용 계좌', '114', '0', '4', '0', 'skt', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(12, '요금 확인서 팩스 발송', '114', '0', '5', '0', 'skt', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(13, '미 환급금 조회', '114', '0', '6', '0', 'skt', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(14, '', '114', '0', '100', '0', 'skt', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(16, '상담 사 연결', '114', '1', '-', '0', 'skt', '09:00:00', '24:00:00', 1, NULL, NULL, '1', NULL, NULL),
(17, '상담원 연결을 원하시면', '114', '1', '1', '#', 'skt', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(18, '아니면', '114', '1', '2', '#', 'skt', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(19, '', '114', '1', '100', '#', 'skt', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- 테이블 구조 `arsee_ars_infos_holiday`
--

CREATE TABLE IF NOT EXISTS `arsee_ars_infos_holiday` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text COLLATE utf8_unicode_ci,
  `number` text COLLATE utf8_unicode_ci,
  `depth` text COLLATE utf8_unicode_ci,
  `indexs` text COLLATE utf8_unicode_ci,
  `parent` text COLLATE utf8_unicode_ci,
  `company` text COLLATE utf8_unicode_ci,
  `starttime` time DEFAULT NULL,
  `endtime` time DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  `info` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `normal` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `error` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `star` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sharp` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- 테이블의 덤프 데이터 `arsee_ars_infos_holiday`
--


-- --------------------------------------------------------

--
-- 테이블 구조 `arsee_ars_infos_update`
--

CREATE TABLE IF NOT EXISTS `arsee_ars_infos_update` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text COLLATE utf8_unicode_ci,
  `number` text COLLATE utf8_unicode_ci,
  `depth` text COLLATE utf8_unicode_ci,
  `indexs` text COLLATE utf8_unicode_ci,
  `parent` text COLLATE utf8_unicode_ci,
  `company` text COLLATE utf8_unicode_ci,
  `starttime` time DEFAULT NULL,
  `endtime` time DEFAULT NULL,
  `AmPm` text COLLATE utf8_unicode_ci,
  `count` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- 테이블의 덤프 데이터 `arsee_ars_infos_update`
--


-- --------------------------------------------------------

--
-- 테이블 구조 `arsee_ars_infos_update_holiday`
--

CREATE TABLE IF NOT EXISTS `arsee_ars_infos_update_holiday` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text COLLATE utf8_unicode_ci,
  `number` text COLLATE utf8_unicode_ci,
  `depth` text COLLATE utf8_unicode_ci,
  `indexs` text COLLATE utf8_unicode_ci,
  `parent` text COLLATE utf8_unicode_ci,
  `company` text COLLATE utf8_unicode_ci,
  `starttime` time DEFAULT NULL,
  `endtime` time DEFAULT NULL,
  `AmPm` text COLLATE utf8_unicode_ci,
  `count` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- 테이블의 덤프 데이터 `arsee_ars_infos_update_holiday`
--

INSERT INTO `arsee_ars_infos_update_holiday` (`id`, `text`, `number`, `depth`, `indexs`, `parent`, `company`, `starttime`, `endtime`, `AmPm`, `count`) VALUES
(1, '실시간 요금', '114', '2', '2', 's1', 'olleh', '11:47:03', '11:47:03', '1', 1),
(2, '유근 및 나쁜', '114', '1', '1', 's', 'olleh', '11:47:03', '11:47:03', '1', 1),
(3, '청구요금 사진은', '114', '2', '1', 's1', 'olleh', '11:47:03', '11:47:03', '1', 1),
(4, '', '114', '1', '100', 's', 'olleh', '11:47:03', '11:47:03', '1', 1),
(5, '', '114', '2', '100', 's1', 'olleh', '11:47:03', '11:47:03', '1', 1),
(6, '인 실시간 요금', '114', '2', '2', 's1', 'olleh', '11:47:03', '11:47:03', '1', 1),
(7, '청구요금 사귀는', '114', '2', '1', 's1', 'olleh', '11:47:03', '11:47:03', '1', 1),
(8, '요금이 나쁜 일이', '114', '1', '1', '2', 'olleh', '13:09:02', '13:09:02', '1', 1),
(9, '', '114', '1', '100', '2', 'olleh', '13:09:02', '13:09:02', '1', 1),
(10, '요금이 나쁜', '114', '1', '1', '2', 'olleh', '13:09:02', '13:09:02', '1', 1),
(11, '요금이 나 뿐인', '114', '1', '1', '2', 'olleh', '13:09:02', '13:09:02', '1', 1);

-- --------------------------------------------------------

--
-- 테이블 구조 `arsee_ars_other_infos`
--

CREATE TABLE IF NOT EXISTS `arsee_ars_other_infos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text COLLATE utf8_unicode_ci,
  `name_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- 테이블의 덤프 데이터 `arsee_ars_other_infos`
--

INSERT INTO `arsee_ars_other_infos` (`id`, `text`, `name_id`) VALUES
(1, '안녕하세요', 18),
(2, '반갑습니다', 18),
(3, 'ㅎ', 18),
(4, 'ㅎ', 18),
(5, 'ㅎ', 18);

-- --------------------------------------------------------

--
-- 테이블 구조 `arsee_ars_other_infos_holiday`
--

CREATE TABLE IF NOT EXISTS `arsee_ars_other_infos_holiday` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text COLLATE utf8_unicode_ci,
  `name_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- 테이블의 덤프 데이터 `arsee_ars_other_infos_holiday`
--


-- --------------------------------------------------------

--
-- 테이블 구조 `arsee_calling_infos`
--

CREATE TABLE IF NOT EXISTS `arsee_calling_infos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `who` text COLLATE utf8_unicode_ci NOT NULL,
  `where` text COLLATE utf8_unicode_ci NOT NULL,
  `company` text COLLATE utf8_unicode_ci NOT NULL,
  `number` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- 테이블의 덤프 데이터 `arsee_calling_infos`
--


-- --------------------------------------------------------

--
-- 테이블 구조 `arsee_image_paths`
--

CREATE TABLE IF NOT EXISTS `arsee_image_paths` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone` text COLLATE utf8_unicode_ci NOT NULL,
  `path` text COLLATE utf8_unicode_ci NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `count` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- 테이블의 덤프 데이터 `arsee_image_paths`
--

INSERT INTO `arsee_image_paths` (`id`, `phone`, `path`, `date`, `count`) VALUES
(1, '01021861953', '01021861953--20140814_011327.jpg', '2014-09-14 13:13:32', 0),
(2, '01021861953', '01021861953--20140814_011338.jpg', '2014-09-14 13:13:44', 0),
(3, '01021861953', '01021861953--20140814_011814.jpg', '2014-09-14 13:18:18', 0),
(4, '01021861953', '01021861953--20140814_011823.jpg', '2014-09-14 13:18:27', 0),
(5, '01021861953', '01021861953--20140814_011830.jpg', '2014-09-14 13:18:34', 0),
(6, '01021861953', '01021861953--20140814_012012.jpg', '2014-09-14 13:20:16', 0),
(7, '01021861953', '01021861953--20140814_012037.jpg', '2014-09-14 13:20:41', 0),
(8, '01021861953', '01021861953--20140814_012100.jpg', '2014-09-14 13:21:03', 0),
(9, '01021861953', '01021861953--20140814_012902.jpg', '2014-09-14 13:29:06', 0),
(10, '01021861953', '01021861953--20140814_012936.jpg', '2014-09-14 13:29:40', 0),
(11, '01021861953', '01021861953--20140814_012943.jpg', '2014-09-14 13:29:46', 0);

-- --------------------------------------------------------

--
-- 테이블 구조 `arsee_kwrds`
--

CREATE TABLE IF NOT EXISTS `arsee_kwrds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key_word` text COLLATE utf8_unicode_ci,
  `number` text COLLATE utf8_unicode_ci,
  `depth` text COLLATE utf8_unicode_ci,
  `parent` text COLLATE utf8_unicode_ci,
  `indexs` text COLLATE utf8_unicode_ci,
  `count` int(11) DEFAULT NULL,
  `company` text COLLATE utf8_unicode_ci,
  `ars_info_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- 테이블의 덤프 데이터 `arsee_kwrds`
--


-- --------------------------------------------------------

--
-- 테이블 구조 `arsee_kwrds_holiday`
--

CREATE TABLE IF NOT EXISTS `arsee_kwrds_holiday` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key_word` text COLLATE utf8_unicode_ci,
  `number` text COLLATE utf8_unicode_ci,
  `depth` text COLLATE utf8_unicode_ci,
  `parent` text COLLATE utf8_unicode_ci,
  `indexs` text COLLATE utf8_unicode_ci,
  `count` int(11) DEFAULT NULL,
  `company` text COLLATE utf8_unicode_ci,
  `ars_info_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- 테이블의 덤프 데이터 `arsee_kwrds_holiday`
--


-- --------------------------------------------------------

--
-- 테이블 구조 `arsee_manager_datas`
--

CREATE TABLE IF NOT EXISTS `arsee_manager_datas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` text COLLATE utf8_unicode_ci NOT NULL,
  `passwd` text COLLATE utf8_unicode_ci NOT NULL,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `phone` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- 테이블의 덤프 데이터 `arsee_manager_datas`
--

INSERT INTO `arsee_manager_datas` (`id`, `email`, `passwd`, `name`, `phone`) VALUES
(1, 'chlduq04@gmail.com', '3774', '최웅엽', '01040750607');

-- --------------------------------------------------------

--
-- 테이블 구조 `arsee_qna_datas`
--

CREATE TABLE IF NOT EXISTS `arsee_qna_datas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `info_id` int(11) DEFAULT NULL,
  `text` text COLLATE utf8_unicode_ci,
  `isPoint` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isText` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isCheck` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isRadio` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `question1` text COLLATE utf8_unicode_ci,
  `question2` text COLLATE utf8_unicode_ci,
  `question3` text COLLATE utf8_unicode_ci,
  `question4` text COLLATE utf8_unicode_ci,
  `question5` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- 테이블의 덤프 데이터 `arsee_qna_datas`
--

INSERT INTO `arsee_qna_datas` (`id`, `info_id`, `text`, `isPoint`, `isText`, `isCheck`, `isRadio`, `question1`, `question2`, `question3`, `question4`, `question5`) VALUES
(1, 7, '', '1', '0', '0', '0', '0.0', '0.0', '0.0', '1.0', '0.0'),
(2, 7, '', '1', '0', '0', '0', '0.0', '0.0', '0.0', '1.0', '0.0');

-- --------------------------------------------------------

--
-- 테이블 구조 `arsee_qna_infos`
--

CREATE TABLE IF NOT EXISTS `arsee_qna_infos` (
  `number` text COLLATE utf8_unicode_ci,
  `company` text COLLATE utf8_unicode_ci,
  `text` text COLLATE utf8_unicode_ci,
  `isPoint` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isText` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isRadio` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isCheck` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `question1` text COLLATE utf8_unicode_ci,
  `question2` text COLLATE utf8_unicode_ci,
  `question3` text COLLATE utf8_unicode_ci,
  `question4` text COLLATE utf8_unicode_ci,
  `question5` text COLLATE utf8_unicode_ci,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- 테이블의 덤프 데이터 `arsee_qna_infos`
--

INSERT INTO `arsee_qna_infos` (`number`, `company`, `text`, `isPoint`, `isText`, `isRadio`, `isCheck`, `question1`, `question2`, `question3`, `question4`, `question5`, `id`) VALUES
('114', 'skt', 'hhhhh', '0', '1', '0', '0', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 6),
('114', 'skt', '하이', '1', '0', '0', '0', '1', '2', '3', '4', '5', 5),
('114', 'olleh', '안녕하세요', '1', '0', '0', '0', '1번 답', '2번 답', '3번 답', '4번 답', '5번 답', 7),
('', '', 'asdfasdf', '1', '0', '0', '0', 'aa', 'aaaa', 'ssdf', 'sdfa', 'asdfasdf', 9);

-- --------------------------------------------------------

--
-- 테이블 구조 `arsee_table_update_check`
--

CREATE TABLE IF NOT EXISTS `arsee_table_update_check` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updates` int(11) NOT NULL,
  `lastupdate` date NOT NULL DEFAULT '0000-00-00',
  `number` text COLLATE utf8_unicode_ci NOT NULL,
  `company` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- 테이블의 덤프 데이터 `arsee_table_update_check`
--

INSERT INTO `arsee_table_update_check` (`id`, `date`, `updates`, `lastupdate`, `number`, `company`) VALUES
(1, '2014-09-14 11:47:03', 1, '2014-09-14', '114', 'olleh'),
(2, '2014-09-14 11:47:03', 1, '2014-09-14', '114', 'olleh');
