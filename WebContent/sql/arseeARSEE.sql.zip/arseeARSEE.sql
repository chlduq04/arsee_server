-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- 호스트: localhost
-- 처리한 시간: 14-09-20 09:36 
-- 서버 버전: 5.1.41
-- PHP 버전: 5.2.12

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 데이터베이스: `arsee`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `arsee_ars_infos`
--

CREATE TABLE IF NOT EXISTS `arsee_ars_infos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text COLLATE utf8_unicode_ci,
  `number` text COLLATE utf8_unicode_ci,
  `depth` text COLLATE utf8_unicode_ci,
  `indexs` text COLLATE utf8_unicode_ci,
  `parent` text COLLATE utf8_unicode_ci,
  `company` text COLLATE utf8_unicode_ci,
  `starttime` time DEFAULT NULL,
  `endtime` time DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  `info` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `normal` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `error` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `star` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sharp` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=99 ;

--
-- 테이블의 덤프 데이터 `arsee_ars_infos`
--

INSERT INTO `arsee_ars_infos` (`id`, `text`, `number`, `depth`, `indexs`, `parent`, `company`, `starttime`, `endtime`, `count`, `info`, `normal`, `error`, `star`, `sharp`) VALUES
(8, '청구요금 확인', '114', '0', '1', '0', 'skt', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(6, 'start', '114', '0', '#', '0', 'skt', '00:00:00', '24:00:00', 1, NULL, NULL, NULL, NULL, '1'),
(7, '상담 사 연결', '114', '0', '0', '0', 'skt', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(9, '당월 실시간 요금', '114', '0', '2', '0', 'skt', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(10, '잔여 무료 통화, 무료 문자', '114', '0', '3', '0', 'skt', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(11, '납부 전용 계좌', '114', '0', '4', '0', 'skt', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(12, '요금 확인서 팩스 발송', '114', '0', '5', '0', 'skt', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(13, '미 환급금 조회', '114', '0', '6', '0', 'skt', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(14, '', '114', '0', '100', '0', 'skt', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(16, '상담 사 연결', '114', '1', '-', '0', 'skt', '09:00:00', '24:00:00', 1, NULL, NULL, '1', NULL, NULL),
(17, '상담원 연결을 원하시면', '114', '1', '1', '#', 'skt', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(18, '아니면', '114', '1', '2', '#', 'skt', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(19, '', '114', '1', '100', '#', 'skt', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(22, 'dfkjaslfjsa. ~ 원하시면', '114', '0', '1', '0', 'olleh', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(23, '~를 원하시면', '114', '0', '2', '0', 'olleh', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(24, '', '114', '0', '100', '0', 'olleh', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(25, '안녕하십니까 동양증권 ARS 서비스입니다', '15880056', '0', '0', '0', 'ëìì¦ê¶', '00:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(26, '느림 말 서비스는 우물 정자와', '15880056', '1', '0', '0', 'ëìì¦ê¶', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(27, '빠른 서비스', '15880056', '1', '1', '0', 'ëìì¦ê¶', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(28, '시세 조회', '15880056', '1', '2', '0', 'ëìì¦ê¶', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(29, '일반 주문wgewg', '15880056', '1', '3', '0', 'ëìì¦ê¶', '09:00:00', '00:00:00', 1, NULL, '1', NULL, NULL, NULL),
(30, '체결 거래내용 및 잔 고 조회', '15880056', '1', '4', '0', 'ëìì¦ê¶', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(31, '이체 서비스', '15880056', '1', '5', '0', 'ëìì¦ê¶', '09:00:00', '00:00:00', 1, NULL, '1', NULL, NULL, NULL),
(32, '사고 등록 및 부가서비스', '15880056', '1', '6', '0', 'ëìì¦ê¶', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(33, '금융상품 매매 서비스', '15880056', '1', '7', '0', 'ëìì¦ê¶', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(34, '청약서비스', '15880056', '1', '8', '0', 'ëìì¦ê¶', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(35, '서비스 이용도 중 전단계 메뉴로의 이동은 우물 정자를 다시 들으시려면 별 포를 눌러 주십시오 ', '15880056', '1', '100', '0', 'ëìì¦ê¶', '09:00:00', '24:00:00', 1, NULL, '1', NULL, NULL, NULL),
(36, '안녕하십니까 동양증권 ARS 서비스입니다 느림말 서비스는 우물정자와 영번을 눌러주십시오 서비스 이용도중 전단계 메뉴로의 이동은 우물정자를 다시 들으시려면 별표를 눌러주십시오', '15880056', '0', 's', '0', 'olleh', '00:00:00', '23:59:59', 1, '1', NULL, NULL, NULL, NULL),
(53, '이체 서비스는 5번', '15880056', '0', '5', '0', 'olleh', '00:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(49, '빠른 서비스는 1번', '15880056', '0', '1', '0', 'olleh', '00:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(51, '일반주문은 3번', '15880056', '0', '3', '0', 'olleh', '00:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(52, '체결 거래내용 및 잔고 조회는 4번', '15880056', '0', '4', '0', 'olleh', '00:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(50, '시세조회는 2번', '15880056', '0', '2', '0', 'olleh', '00:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(54, '사고 등록 및 부가서비스는 6번', '15880056', '0', '6', '0', 'olleh', '00:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(55, '금융상품 매매 서비스는 7번', '15880056', '0', '7', '0', 'olleh', '00:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(56, '청약서비스는 8번', '15880056', '0', '8', '0', 'olleh', '00:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(57, '상담원 연결은 0번', '15880056', '0', '0', '0', 'olleh', '00:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(58, '빠른 서비스입니다', '15880056', '1', 's', '1', 'olleh', '00:00:00', '23:59:59', 1, '1', NULL, NULL, NULL, NULL),
(59, '빠른 현재가', '15880056', '1', '1', '1', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(60, '빠른 매도', '15880056', '1', '2', '1', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(61, '빠른 매수', '15880056', '1', '3', '1', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(62, '빠른 정정', '15880056', '1', '4', '1', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(63, '빠른 취소', '15880056', '1', '5', '1', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(64, '', '15880056', '1', '100', '1', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(65, '시세조회입니다', '15880056', '1', 's', '2', 'olleh', '00:00:00', '23:59:59', 1, '1', NULL, NULL, NULL, NULL),
(66, '현재가 및 지수 안내는 1번을 눌러주십시오', '15880056', '1', '1', '2', 'olleh', '00:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(67, '일반주문입니다', '15880056', '1', 's', '3', 'olleh', '00:00:00', '23:59:59', 1, '1', NULL, NULL, NULL, NULL),
(68, '매수 매도 주문', '15880056', '1', '1', '3', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(69, '정정 취소 주문', '15880056', '1', '2', '3', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(70, '예약 주문', '15880056', '1', '4', '3', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(71, '', '15880056', '1', '100', '3', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(72, '체결 거래내용 및 잔고 조회입니다', '15880056', '1', 's', '4', 'olleh', '00:00:00', '23:59:59', 1, '1', NULL, NULL, NULL, NULL),
(73, '채결 내역 조회', '15880056', '1', '1', '4', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(74, '거래 내역 조회', '15880056', '1', '2', '4', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(75, '잔고 조회', '15880056', '1', '3', '4', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(76, '', '15880056', '1', '100', '4', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(77, '이체 서비스입니다', '15880056', '1', 's', '5', 'olleh', '00:00:00', '23:59:59', 1, '1', NULL, NULL, NULL, NULL),
(78, '자금 이체', '15880056', '1', '1', '5', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(79, '가상 계좌 조회', '15880056', '1', '2', '5', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(80, '', '15880056', '1', '100', '5', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(81, '사고 등록 및 부가서비스입니다', '15880056', '1', 's', '6', 'olleh', '00:00:00', '23:59:59', 1, '1', NULL, NULL, NULL, NULL),
(82, '사고 등록', '15880056', '1', '1', '6', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(83, '비밀번호 등록변경', '15880056', '1', '2', '6', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(84, '카드 사용 등록', '15880056', '1', '3', '6', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(85, '팩스 서비스', '15880056', '1', '4', '6', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(86, '자동 투자 상품 변경', '15880056', '1', '5', '6', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(87, '지정 위치 안내', '15880056', '1', '6', '6', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(88, '', '15880056', '1', '100', '6', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(89, '금융상품 매매입니다', '15880056', '1', 's', '7', 'olleh', '00:00:00', '23:59:59', 1, '1', NULL, NULL, NULL, NULL),
(90, '적립식 펀드 메뉴', '15880056', '1', '1', '7', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(91, '', '15880056', '1', '100', '7', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(92, '청약서비스입니다', '15880056', '1', 's', '8', 'olleh', '00:00:00', '23:59:59', 1, '1', NULL, NULL, NULL, NULL),
(93, '청약 일정 안내', '15880056', '1', '1', '8', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(94, '청약 접수', '15880056', '1', '2', '8', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(95, '청약 취소', '15880056', '1', '3', '8', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(96, '청약 내역 조회', '15880056', '1', '4', '8', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(97, '', '15880056', '1', '100', '8', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL),
(98, '상담원 연결 서비스입니다 ', '15880056', '1', '100', '0', 'olleh', '09:00:00', '23:59:59', 1, NULL, '1', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- 테이블 구조 `arsee_ars_infos_holiday`
--

CREATE TABLE IF NOT EXISTS `arsee_ars_infos_holiday` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text COLLATE utf8_unicode_ci,
  `number` text COLLATE utf8_unicode_ci,
  `depth` text COLLATE utf8_unicode_ci,
  `indexs` text COLLATE utf8_unicode_ci,
  `parent` text COLLATE utf8_unicode_ci,
  `company` text COLLATE utf8_unicode_ci,
  `starttime` time DEFAULT NULL,
  `endtime` time DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  `info` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `normal` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `error` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `star` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sharp` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- 테이블의 덤프 데이터 `arsee_ars_infos_holiday`
--


-- --------------------------------------------------------

--
-- 테이블 구조 `arsee_ars_infos_update`
--

CREATE TABLE IF NOT EXISTS `arsee_ars_infos_update` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text COLLATE utf8_unicode_ci,
  `number` text COLLATE utf8_unicode_ci,
  `depth` text COLLATE utf8_unicode_ci,
  `indexs` text COLLATE utf8_unicode_ci,
  `parent` text COLLATE utf8_unicode_ci,
  `company` text COLLATE utf8_unicode_ci,
  `starttime` time DEFAULT NULL,
  `endtime` time DEFAULT NULL,
  `AmPm` text COLLATE utf8_unicode_ci,
  `count` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- 테이블의 덤프 데이터 `arsee_ars_infos_update`
--

INSERT INTO `arsee_ars_infos_update` (`id`, `text`, `number`, `depth`, `indexs`, `parent`, `company`, `starttime`, `endtime`, `AmPm`, `count`) VALUES
(1, '미국 세금 계산서 입금 관련 확인 올레 닷컴 내 스마트 폰 ', '114', '3', '100', '215', 'olleh', '14:47:16', '14:47:16', '1', 1),
(2, '미국 세금 계산서 입금 당일 확인 올레 닷컴 내 스마트 폰 ', '114', '3', '100', '215', 'olleh', '14:47:16', '14:47:16', '1', 1),
(3, '세금 계산서 입금 관련 확인 올레 닷컴 내 스마트 폰 ', '114', '3', '100', '215', 'olleh', '14:47:16', '14:47:16', '1', 1);

-- --------------------------------------------------------

--
-- 테이블 구조 `arsee_ars_infos_update_holiday`
--

CREATE TABLE IF NOT EXISTS `arsee_ars_infos_update_holiday` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text COLLATE utf8_unicode_ci,
  `number` text COLLATE utf8_unicode_ci,
  `depth` text COLLATE utf8_unicode_ci,
  `indexs` text COLLATE utf8_unicode_ci,
  `parent` text COLLATE utf8_unicode_ci,
  `company` text COLLATE utf8_unicode_ci,
  `starttime` time DEFAULT NULL,
  `endtime` time DEFAULT NULL,
  `AmPm` text COLLATE utf8_unicode_ci,
  `count` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=60 ;

--
-- 테이블의 덤프 데이터 `arsee_ars_infos_update_holiday`
--

INSERT INTO `arsee_ars_infos_update_holiday` (`id`, `text`, `number`, `depth`, `indexs`, `parent`, `company`, `starttime`, `endtime`, `AmPm`, `count`) VALUES
(1, '실시간 요금', '114', '2', '2', 's1', 'olleh', '11:47:03', '11:47:03', '1', 1),
(2, '유근 및 나쁜', '114', '1', '1', 's', 'olleh', '11:47:03', '13:49:14', '1', 2),
(3, '청구요금 사진은', '114', '2', '1', 's1', 'olleh', '11:47:03', '11:47:03', '1', 1),
(4, '', '114', '1', '100', 's', 'olleh', '11:47:03', '13:49:14', '1', 2),
(5, '', '114', '2', '100', 's1', 'olleh', '11:47:03', '11:47:03', '1', 1),
(6, '인 실시간 요금', '114', '2', '2', 's1', 'olleh', '11:47:03', '11:47:03', '1', 1),
(7, '청구요금 사귀는', '114', '2', '1', 's1', 'olleh', '11:47:03', '11:47:03', '1', 1),
(8, '요금이 나쁜 일이', '114', '1', '1', '2', 'olleh', '13:09:02', '14:46:30', '1', 3),
(9, '', '114', '1', '100', '2', 'olleh', '13:09:02', '21:27:44', '1', 5),
(10, '요금이 나쁜', '114', '1', '1', '2', 'olleh', '13:09:02', '14:46:30', '1', 3),
(11, '요금이 나 뿐인', '114', '1', '1', '2', 'olleh', '13:09:02', '14:46:30', '1', 3),
(12, '문자로 하는 ars 애니 문제를 고객님의 휴대폰으로 보내 드 렸습니다 이용해 주셔서 감사합니다 ', '114', '1', '100', '1', 'olleh', '13:49:14', '13:49:14', '1', 1),
(13, '문자로 하는 ars 애니 문제를 고객님의 휴대폰으로 보내 드 렸습니다 이용해 주셔서 감사합니다 k ', '114', '1', '100', '1', 'olleh', '13:49:14', '13:49:14', '1', 1),
(14, '문자로 하는 ars 애니 문제를 고객님의 휴대폰으로 보내 드 렸습니다 이용해 주셔서 감사합니다 kt ', '114', '1', '100', '1', 'olleh', '13:49:14', '13:49:14', '1', 1),
(15, '6을 및 나쁜', '114', '1', '1', 's', 'olleh', '13:49:14', '13:49:14', '1', 1),
(16, '유근 및 나쁜 일 발이 드레스 rec 요금제 입 안이 분실정지 안내 기관 및 ', '114', '1', '100', 's', 'olleh', '13:49:14', '13:49:14', '1', 1),
(17, '문자로 하는 ars 애니 문제를 고객님의 휴대폰으로 보내 드 렸습니다 이용해 주셔서 감사합니다 케익 ', '114', '1', '100', '1', 'olleh', '13:49:14', '13:49:14', '1', 1),
(18, '문자로 하는 ars 애니 문제를 고객님에 휴대폰으로 보내 드 렸습니다 이용해 주셔서 감사합니다 ', '114', '1', '100', '1', 'olleh', '13:49:14', '13:49:14', '1', 1),
(19, '청구 요금 사기는', '114', '2', '1', '21', 'olleh', '14:36:27', '14:36:27', '1', 1),
(20, '', '114', '2', '100', '21', 'olleh', '14:36:27', '14:36:27', '1', 1),
(21, '청구요금 사기는', '114', '2', '1', '21', 'olleh', '14:36:27', '14:36:27', '1', 1),
(22, '청구 요금 확인', '114', '2', '1', '21', 'olleh', '14:36:27', '14:36:27', '1', 1),
(23, '청구요금 사귀는', '114', '2', '1', '21', 'olleh', '14:36:27', '14:36:27', '1', 1),
(24, '고객님에 생년월일 6 자리 눌러 주세요 ', '114', '3', '100', '213', 'olleh', '14:36:31', '14:36:31', '1', 1),
(25, '그게 님의 생년월일 6 자리 눌러 주세요 ', '114', '3', '100', '213', 'olleh', '14:36:31', '14:36:31', '1', 1),
(26, '고객님의 생년월일 6 자리 눌러 주세요 ', '114', '3', '100', '213', 'olleh', '14:36:31', '14:36:31', '1', 1),
(27, '그게 니 네 생년 월일 6 자리 눌러 주세요 ', '114', '3', '100', '213', 'olleh', '14:36:31', '14:36:31', '1', 1),
(28, '고객님에 생년월일 6 자리를 해 주세요 ', '114', '3', '100', '213', 'olleh', '14:36:31', '14:36:31', '1', 1),
(29, '더 느리게 하는 일 셨습니다 주인님 ', '114', '0', '100', '', 'olleh', '15:13:23', '15:13:23', '1', 1),
(30, '바늘이 행운이 셨습니다 주인님 ', '114', '0', '100', '', 'olleh', '15:13:23', '15:13:23', '1', 1),
(31, '바늘이 행운이겠습니다 그게 님 ', '114', '0', '100', '', 'olleh', '15:13:23', '15:13:23', '1', 1),
(32, '하늘이 큰일을 셨습니다 주인님 ', '114', '0', '100', '', 'olleh', '15:13:23', '15:13:23', '1', 1),
(33, '하늘이 행운이 셨습니다 주인님 ', '114', '0', '100', '', 'olleh', '15:13:23', '15:13:23', '1', 1),
(34, '요금 및 나쁜 일 ', '114', '1', '100', 's', 'olleh', '20:54:06', '20:56:23', '1', 2),
(35, '요금이 나쁜 일 ', '114', '1', '100', 's', 'olleh', '20:54:06', '20:56:23', '1', 2),
(36, '유근 및 나쁜 일 ', '114', '1', '100', 's', 'olleh', '20:54:06', '20:56:23', '1', 2),
(37, '6 은 미 나쁜 일 ', '114', '1', '100', 's', 'olleh', '20:54:06', '20:56:23', '1', 2),
(38, '6 은 및 나쁜 일 ', '114', '1', '100', 's', 'olleh', '20:54:06', '20:56:23', '1', 2),
(39, '나의 소개 서비스 해 주는 서비스 신청 ', '114', '2', '100', 'ss', 'olleh', '20:56:34', '20:56:34', '1', 1),
(40, '나이스 가이 서비스 해 주는 서비스 신청 ', '114', '2', '100', 'ss', 'olleh', '20:56:35', '20:56:35', '1', 1),
(41, '나이트가 서비스 해 주는 서비스 신청 ', '114', '2', '100', 'ss', 'olleh', '20:56:35', '20:56:35', '1', 1),
(42, '나이프가 서비스 해 주는 서비스 신청 ', '114', '2', '100', 'ss', 'olleh', '20:56:35', '20:56:35', '1', 1),
(43, '라이프가 서비스 해 주는 서비스 신청 ', '114', '2', '100', 'ss', 'olleh', '20:56:35', '20:56:35', '1', 1),
(44, '유근 및 나쁜 일 발이 드레스 rec 윤 재민 이 바리 ', '114', '2', '100', '22', 'olleh', '21:06:08', '21:06:08', '1', 1),
(45, '유근 및 나쁜 일 바리 드레스 rec 윤 재민 이 바리 ', '114', '2', '100', '22', 'olleh', '21:06:08', '21:06:08', '1', 1),
(46, '유근 및 나쁜 일 발이 드레스 rec 윤 재민 입안이 ', '114', '2', '100', '22', 'olleh', '21:06:09', '21:06:09', '1', 1),
(47, '유근 및 나쁜 일 다리 드레스 rec 윤 재민 이 바리 ', '114', '2', '100', '22', 'olleh', '21:06:09', '21:06:09', '1', 1),
(48, '유근 및 나쁜 일 바리 드레스 rec 윤 재민 입안이 ', '114', '2', '100', '22', 'olleh', '21:06:09', '21:06:09', '1', 1),
(49, '저녁에 전화 요금 확인 ', '114', '2', '100', '21', 'olleh', '21:24:42', '21:24:42', '1', 1),
(50, '저녁에 전화 요금 확인서 ', '114', '2', '100', '21', 'olleh', '21:24:42', '21:24:42', '1', 1),
(51, '0 9 6 0 4 0 개 전화 요금 확인 ', '114', '2', '100', '21', 'olleh', '21:24:42', '21:24:42', '1', 1),
(52, '0 9 6 0 4 0 개 전화 요금 확인서 ', '114', '2', '100', '21', 'olleh', '21:24:42', '21:24:42', '1', 1),
(53, '유근 및 야근이니 1 1 1 2 2 104기 c 읽은 재 민이 바리 ', '114', '2', '100', '22', 'olleh', '21:26:35', '21:26:35', '1', 1),
(54, '유근 및 나쁜 일 반 1 2 2 104기 c 읽은 재 민이 바리 ', '114', '2', '100', '22', 'olleh', '21:26:35', '21:26:35', '1', 1),
(55, '유근 및 나쁜 1 1 1 2 2 104기 c 읽은 재 민이 바리 ', '114', '2', '100', '22', 'olleh', '21:26:35', '21:26:35', '1', 1),
(56, '유근 및 야근이니 1 1 1 2 2 104기 c 6은 재민이 바리 ', '114', '2', '100', '22', 'olleh', '21:26:35', '21:26:35', '1', 1),
(57, '유근 및 나쁜 일 반 1 2 2 104기 c 6은 재민이 바리 ', '114', '2', '100', '22', 'olleh', '21:26:35', '21:26:35', '1', 1),
(58, '요금이', '114', '1', '1', '2', 'olleh', '21:27:43', '21:27:44', '1', 2),
(59, '예금 상품 챙겨서 분실정지 단말기 보급 및 통화 금지 asn1', '114', '1', '3', '2', 'olleh', '21:27:44', '21:27:44', '1', 1);

-- --------------------------------------------------------

--
-- 테이블 구조 `arsee_ars_other_infos`
--

CREATE TABLE IF NOT EXISTS `arsee_ars_other_infos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text COLLATE utf8_unicode_ci,
  `name_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- 테이블의 덤프 데이터 `arsee_ars_other_infos`
--

INSERT INTO `arsee_ars_other_infos` (`id`, `text`, `name_id`) VALUES
(1, '안녕하세요', 18),
(2, '반갑습니다', 18),
(3, 'ㅎ', 18),
(4, 'ㅎ', 18),
(5, 'ㅎ', 18);

-- --------------------------------------------------------

--
-- 테이블 구조 `arsee_ars_other_infos_holiday`
--

CREATE TABLE IF NOT EXISTS `arsee_ars_other_infos_holiday` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text COLLATE utf8_unicode_ci,
  `name_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- 테이블의 덤프 데이터 `arsee_ars_other_infos_holiday`
--


-- --------------------------------------------------------

--
-- 테이블 구조 `arsee_calling_infos`
--

CREATE TABLE IF NOT EXISTS `arsee_calling_infos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `who` text COLLATE utf8_unicode_ci NOT NULL,
  `where` text COLLATE utf8_unicode_ci NOT NULL,
  `company` text COLLATE utf8_unicode_ci NOT NULL,
  `number` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- 테이블의 덤프 데이터 `arsee_calling_infos`
--


-- --------------------------------------------------------

--
-- 테이블 구조 `arsee_image_paths`
--

CREATE TABLE IF NOT EXISTS `arsee_image_paths` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone` text COLLATE utf8_unicode_ci NOT NULL,
  `path` text COLLATE utf8_unicode_ci NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `count` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- 테이블의 덤프 데이터 `arsee_image_paths`
--

INSERT INTO `arsee_image_paths` (`id`, `phone`, `path`, `date`, `count`) VALUES
(1, '01021861953', '01021861953--20140814_011327.jpg', '2014-09-14 13:13:32', 0),
(2, '01021861953', '01021861953--20140814_011338.jpg', '2014-09-14 13:13:44', 0),
(3, '01021861953', '01021861953--20140814_011814.jpg', '2014-09-14 13:18:18', 0),
(4, '01021861953', '01021861953--20140814_011823.jpg', '2014-09-14 13:18:27', 0),
(5, '01021861953', '01021861953--20140814_011830.jpg', '2014-09-14 13:18:34', 0),
(6, '01021861953', '01021861953--20140814_012012.jpg', '2014-09-14 13:20:16', 0),
(7, '01021861953', '01021861953--20140814_012037.jpg', '2014-09-14 13:20:41', 0),
(8, '01021861953', '01021861953--20140814_012100.jpg', '2014-09-14 13:21:03', 0),
(9, '01021861953', '01021861953--20140814_012902.jpg', '2014-09-14 13:29:06', 0),
(10, '01021861953', '01021861953--20140814_012936.jpg', '2014-09-14 13:29:40', 0),
(11, '01021861953', '01021861953--20140814_012943.jpg', '2014-09-14 13:29:46', 0),
(12, '01021861953', '01021861953--20140814_014900.jpg', '2014-09-14 13:49:05', 0);

-- --------------------------------------------------------

--
-- 테이블 구조 `arsee_kwrds`
--

CREATE TABLE IF NOT EXISTS `arsee_kwrds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key_word` text COLLATE utf8_unicode_ci,
  `number` text COLLATE utf8_unicode_ci,
  `depth` text COLLATE utf8_unicode_ci,
  `parent` text COLLATE utf8_unicode_ci,
  `indexs` text COLLATE utf8_unicode_ci,
  `count` int(11) DEFAULT NULL,
  `company` text COLLATE utf8_unicode_ci,
  `ars_info_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- 테이블의 덤프 데이터 `arsee_kwrds`
--


-- --------------------------------------------------------

--
-- 테이블 구조 `arsee_kwrds_holiday`
--

CREATE TABLE IF NOT EXISTS `arsee_kwrds_holiday` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key_word` text COLLATE utf8_unicode_ci,
  `number` text COLLATE utf8_unicode_ci,
  `depth` text COLLATE utf8_unicode_ci,
  `parent` text COLLATE utf8_unicode_ci,
  `indexs` text COLLATE utf8_unicode_ci,
  `count` int(11) DEFAULT NULL,
  `company` text COLLATE utf8_unicode_ci,
  `ars_info_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- 테이블의 덤프 데이터 `arsee_kwrds_holiday`
--


-- --------------------------------------------------------

--
-- 테이블 구조 `arsee_manager_datas`
--

CREATE TABLE IF NOT EXISTS `arsee_manager_datas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` text COLLATE utf8_unicode_ci NOT NULL,
  `passwd` text COLLATE utf8_unicode_ci NOT NULL,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `phone` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- 테이블의 덤프 데이터 `arsee_manager_datas`
--

INSERT INTO `arsee_manager_datas` (`id`, `email`, `passwd`, `name`, `phone`) VALUES
(1, 'chlduq04@gmail.com', '3774', '최웅엽', '01040750607');

-- --------------------------------------------------------

--
-- 테이블 구조 `arsee_qna_datas`
--

CREATE TABLE IF NOT EXISTS `arsee_qna_datas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `info_id` int(11) DEFAULT NULL,
  `text` text COLLATE utf8_unicode_ci,
  `isPoint` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isText` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isCheck` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isRadio` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `question1` text COLLATE utf8_unicode_ci,
  `question2` text COLLATE utf8_unicode_ci,
  `question3` text COLLATE utf8_unicode_ci,
  `question4` text COLLATE utf8_unicode_ci,
  `question5` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- 테이블의 덤프 데이터 `arsee_qna_datas`
--

INSERT INTO `arsee_qna_datas` (`id`, `info_id`, `text`, `isPoint`, `isText`, `isCheck`, `isRadio`, `question1`, `question2`, `question3`, `question4`, `question5`) VALUES
(1, 7, '', '1', '0', '0', '0', '0.0', '0.0', '0.0', '1.0', '0.0'),
(2, 7, '', '1', '0', '0', '0', '0.0', '0.0', '0.0', '1.0', '0.0'),
(3, 7, '', '1', '0', '0', '0', '0.0', '0.0', '0.0', '1.0', '0.0');

-- --------------------------------------------------------

--
-- 테이블 구조 `arsee_qna_infos`
--

CREATE TABLE IF NOT EXISTS `arsee_qna_infos` (
  `number` text COLLATE utf8_unicode_ci,
  `company` text COLLATE utf8_unicode_ci,
  `text` text COLLATE utf8_unicode_ci,
  `isPoint` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isText` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isRadio` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isCheck` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `question1` text COLLATE utf8_unicode_ci,
  `question2` text COLLATE utf8_unicode_ci,
  `question3` text COLLATE utf8_unicode_ci,
  `question4` text COLLATE utf8_unicode_ci,
  `question5` text COLLATE utf8_unicode_ci,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=48 ;

--
-- 테이블의 덤프 데이터 `arsee_qna_infos`
--

INSERT INTO `arsee_qna_infos` (`number`, `company`, `text`, `isPoint`, `isText`, `isRadio`, `isCheck`, `question1`, `question2`, `question3`, `question4`, `question5`, `id`) VALUES
('114', 'skt', '하이', '1', '0', '0', '0', '1', '2', '3', '4', '5', 5),
('114', 'olleh', '안녕하세요', '1', '0', '0', '0', '1번 답', '2번 답', '3번 답', '4번 답', '5번 답', 7),
('', '', 'asdfasdf', '1', '0', '0', '0', 'aa', 'aaaa', 'ssdf', 'sdfa', 'asdfasdf', 9),
('114', 'skt', '테스트입니다', '1', '0', '0', '0', '안녕', '하시', '입', '니', '까', 11),
('114', 'skt', '테스트좋아', '0', '1', '0', '0', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 47);

-- --------------------------------------------------------

--
-- 테이블 구조 `arsee_table_update_check`
--

CREATE TABLE IF NOT EXISTS `arsee_table_update_check` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updates` int(11) NOT NULL,
  `lastupdate` date NOT NULL DEFAULT '0000-00-00',
  `number` text COLLATE utf8_unicode_ci NOT NULL,
  `company` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- 테이블의 덤프 데이터 `arsee_table_update_check`
--

INSERT INTO `arsee_table_update_check` (`id`, `date`, `updates`, `lastupdate`, `number`, `company`) VALUES
(1, '2014-09-14 11:47:03', 1, '2014-09-14', '114', 'olleh'),
(2, '2014-09-14 11:47:03', 1, '2014-09-14', '114', 'olleh');
